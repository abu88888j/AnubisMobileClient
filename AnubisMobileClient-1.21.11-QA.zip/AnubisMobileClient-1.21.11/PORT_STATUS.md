# Port status

## Done in this scaffold
- [x] Target set to Minecraft 1.21.11 and Java 21.
- [x] GUI no longer depends on ImGui/JNI.
- [x] Catalog includes module IDs derived from the supplied JAR's module class names.
- [x] Touch-friendly toggles, category browsing, pagination.
- [x] Config persistence for enabled flags and settings objects.
- [x] Original defaults retained when present in `modules.json`.

## Not yet ported / not verified
- [ ] Original implementations for combat, movement, finder, render, visual, utility and server-tool modules.
- [ ] Module settings editors in the GUI.
- [ ] Original event bus and mixins.
- [ ] Native picker integration (intentionally not loaded by this UI prototype).
- [ ] Build against remote Maven dependencies (run the GitHub workflow).
- [ ] Launch/crash testing in Zalith on Android ARM64.
- [ ] Renderer-specific tests (OpenGL/Vulkan backend).

A visible toggle is not proof that its original feature has been ported.
