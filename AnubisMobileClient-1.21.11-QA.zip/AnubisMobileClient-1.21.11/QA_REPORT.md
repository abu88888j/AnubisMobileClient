# QA report — Anubis Mobile Client 1.21.11

## Checks performed in this environment
- Java runtime available: OpenJDK 21.0.12.
- Parsed `fabric.mod.json` successfully.
- Parsed `module_catalog.json` successfully; it contains 134 catalog entries.
- Checked that every Java source file has balanced braces (basic structural check).
- Checked that source files reference the bundled catalog resource path.
- Fixed a definite Gradle configuration conflict: `settings.gradle` uses `RepositoriesMode.FAIL_ON_PROJECT_REPOS`, so the redundant project-level `repositories { mavenCentral() }` block was removed from `build.gradle`.

## Checks that could NOT be performed
- A real Gradle build was not possible: Gradle is not installed in this environment and outbound DNS/network access is unavailable, so Gradle and Maven dependencies cannot be downloaded.
- The mod was not launched in Minecraft or Zalith Launcher.
- Android ARM64/native compatibility has not been runtime-tested.
- The catalog toggles are UI/configuration placeholders; the original Anubis modules have not been ported and these toggles do not activate their original behavior.

## Current status
**Not yet build-verified; not a ready-to-install client JAR.** Do not install this as if it were a tested release. A real build and in-game test must be run in an environment with Gradle and repository access.
