# QA report — Anubis Mobile Client 1.21.11

## Review pass (static, no build)
Problems found and fixed:
1. **Build would fail: wrong mappings.** `build.gradle` used Yarn, but every source file uses Mojang names (`KeyMapping`, `GuiGraphics`, `Component`, `Minecraft`). Now `loom.officialMojangMappings()`; the unused `yarn_mappings` property was removed.
2. **Loom/Gradle versions.** Updated to the combination used by Fabric's 1.21.11 example mod: Loom `1.18-SNAPSHOT` with plugin id `net.fabricmc.fabric-loom-remap`, Gradle 9.x. The workflow now pins Gradle (there is no wrapper in the project).
3. **Invalid workflow.** `.github/workflows/build.yml` ended with an empty `concurrency:` key, which GitHub rejects as an invalid workflow. Removed. Also: `permissions: contents: read`, and the `-sources.jar` is no longer uploaded as the client JAR.
4. **`settings.gradle`.** Removed `RepositoriesMode.FAIL_ON_PROJECT_REPOS`; Loom adds its own project repositories and the official template does not set it.
5. **Key binding for 1.21.11.** Now registers a `KeyMapping.Category` and uses the 4-argument constructor shown in Fabric's 1.21.11 docs. Added the lang files (`en_us`, `es_ar`) so the key and category have names.
6. **Possible crash: double background render.** `MobileClickScreen.render` called `renderBackground()` manually; the game already draws the background, and a second call can raise "Can only blur once per frame". Removed.
7. **Layout bug on phones.** Rows were a fixed 7 per page with a 24 px minimum height, so on short screens they ran past the panel and over the footer buttons. The rows per page are now computed from the real height. The page indicator button also left a gap before the next-page button; fixed.
8. **Config path / robustness.** `ModuleStore` read `Minecraft.getInstance()` in a static initializer; it now uses `FabricLoader.getConfigDir()` (same file: `config/anubis-mobile-client.json`). A corrupt config no longer discards the catalog, saving is done through a temp file, and the read methods are synchronized.
9. Cleanups: unused imports, duplicate `hand-aura` in the fallback category lists, `license` field in `fabric.mod.json`, GPL text now bundled in the JAR.

Checks performed:
- All JSON files parse; the catalog has 134 entries and every entry has a category.
- The workflow YAML parses and has no `concurrency` key.
- `javac` syntax pass over all sources: no syntax errors (the only errors are the expected unresolved Minecraft/Fabric/Gson symbols, because those libraries are not available offline).

## Build verification (GitHub Actions)
The "Build Minecraft Client" workflow completes successfully and uploads `AnubisMobileClient-JAR`. Getting there required three more fixes found from real CI output: Gradle must run on JDK 25, Gradle must be 9.7+ (Loom 1.18.4), and the Right Shift constant is `InputConstants.KEY_RSHIFT`.

## Checks that could NOT be performed
- Launching the mod in Minecraft or Zalith Launcher; Android ARM64 / renderer testing.
- The catalog toggles are UI/configuration placeholders; the original Anubis modules have not been ported.

## Current status
**Compiles, but has not been launched in Minecraft/Zalith yet; treat the JAR as untested.** The module toggles only save configuration.
