# Anubis Mobile UI — Minecraft 1.21.11 / Fabric / Java 21

**Status: source project / UI prototype, not a finished Anubis port and compiles in GitHub Actions but has not been launched in-game yet, see QA_REPORT.md.**

This project uses a vanilla Minecraft `Screen` instead of ImGui/JNI for its menu, so the menu itself does not load the native ImGui renderer. It is intended as the base for a touch-friendly Android ARM64 port.

## What is included

- Fabric client entrypoint for Minecraft 1.21.11 / Java 21.
- Touch-sized, paginated GUI with category cycling and ON/OFF switches.
- Local config saved at `config/anubis-mobile-client.json`.
- A bundled module catalog assembled from the supplied Anubis 0.9.9.1 JAR: 134 catalog entries, including names corresponding to 131 compiled `*Module.class` files plus configuration-only entries.
- Original default settings retained where present in `assets/anubis_mobile_client/module_catalog.json`.
- Anubis GPL-3.0 license text included for attribution/compliance reference.
- No ImGui or JNI library is required by this new menu.

## Important limitation — read this

The catalog switches currently **save configuration only**. They do not run Anubis's original module logic. The original `.jar` contains compiled classes, mixins, native libraries, and internal event/config systems; replacing the GUI alone does not port those implementations. This project must not be represented as “all Anubis features working.”

To make a true full port, each module needs its implementation and dependencies migrated from the GPL-3.0 source snapshot, the old ImGui screen/bootstrapping references removed or replaced, and the project built and tested on Minecraft 1.21.11 in Zalith on Android ARM64. The provided binary alone does not prove that native code is compatible with every Android renderer.

## Build baseline

- Minecraft Java Edition 1.21.11
- Java 21 at runtime (the mod is compiled for Java 21); **JDK 25 is needed to run the build** (Fabric Loom 1.18 requirement)
- Fabric Loader 0.19.5 (or a compatible newer loader)
- Fabric API 0.141.6+1.21.11
- Fabric Loom 1.18-SNAPSHOT (plugin id `net.fabricmc.fabric-loom-remap`) with **Mojang official mappings**
- Gradle 9.7+ (the GitHub workflow pins 9.7.0; the project has no Gradle wrapper)

The sources use Mojang class names (`KeyMapping`, `GuiGraphics`, `Component`...), so the build must use `loom.officialMojangMappings()`, not Yarn.

Build in GitHub: Actions -> "Build Minecraft Client" -> Run workflow. The JAR is uploaded as the `AnubisMobileClient-JAR` artifact.
Build locally: run `gradle build` from this directory (Gradle 9.7+ running on JDK 25, network access to Fabric Maven). The JAR is in `build/libs/`.

## Menu

The default key is Right Shift. The actual menu buttons are sized for touch. A phone without a hardware keyboard still needs a launcher key mapper or a future on-screen opening control.

## License / credit

Anubis is marked GPL-3.0-only in the supplied JAR. This project is a separate adaptation scaffold and retains the Anubis license notice for attribution. If you redistribute derivative Anubis code, comply with the full GPL-3.0 terms and preserve the credit requested by the upstream project: “Based on Anubis Client by Horcus and 4ldenz” with a link to https://github.com/4ldenz/Anubis-client.
