package dev.gian.mobileclient;

import com.mojang.blaze3d.platform.InputConstants;
import dev.gian.mobileclient.gui.MobileClickScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class MobileClient implements ClientModInitializer {
    public static final String MOD_ID = "anubis_mobile_client";

    private static KeyMapping openMenu;

    @Override
    public void onInitializeClient() {
        ModuleStore.load();

        // 1.21.11 key mappings need a registered category (translation key: key.category.<namespace>.<path>).
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "menu"));

        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.anubis_mobile_client.open_menu",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_RSHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.consumeClick()) {
                if (client.screen == null) client.setScreen(new MobileClickScreen());
            }
        });
    }
}
