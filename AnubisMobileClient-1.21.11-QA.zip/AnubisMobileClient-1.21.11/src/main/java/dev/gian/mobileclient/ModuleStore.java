package dev.gian.mobileclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Local module catalog and persisted enable-state. Module actions are deliberately separate. */
public final class ModuleStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String RESOURCE = "/assets/anubis_mobile_client/module_catalog.json";
    private static final Path CONFIG = Minecraft.getInstance().gameDirectory.toPath()
            .resolve("config").resolve("anubis-mobile-client.json");
    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();
    private static boolean loaded;

    private ModuleStore() {}

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try (InputStream in = ModuleStore.class.getResourceAsStream(RESOURCE)) {
            if (in == null) throw new IOException("Missing bundled module catalog");
            JsonObject root = JsonParser.parseReader(new java.io.InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject modules = root.getAsJsonObject("modules");
            for (Map.Entry<String, JsonElement> item : modules.entrySet()) {
                JsonObject original = item.getValue().getAsJsonObject();
                boolean enabled = original.has("enabled") && original.get("enabled").getAsBoolean();
                JsonObject settings = original.has("settings") && original.get("settings").isJsonObject()
                        ? original.getAsJsonObject("settings") : new JsonObject();
                String category = original.has("category") ? original.get("category").getAsString() : categoryFor(item.getKey());
                ENTRIES.put(item.getKey(), new Entry(item.getKey(), category, enabled, settings.deepCopy()));
            }
            loadSavedState();
        } catch (Exception e) {
            System.err.println("[Anubis Mobile] Could not load catalog: " + e.getMessage());
        }
    }

    private static void loadSavedState() throws IOException {
        if (!Files.isRegularFile(CONFIG)) return;
        try (Reader reader = Files.newBufferedReader(CONFIG, StandardCharsets.UTF_8)) {
            JsonObject saved = JsonParser.parseReader(reader).getAsJsonObject();
            JsonObject modules = saved.has("modules") ? saved.getAsJsonObject("modules") : new JsonObject();
            for (Map.Entry<String, Entry> item : ENTRIES.entrySet()) {
                if (!modules.has(item.getKey())) continue;
                JsonObject value = modules.getAsJsonObject(item.getKey());
                if (value.has("enabled")) item.getValue().enabled = value.get("enabled").getAsBoolean();
                if (value.has("settings") && value.get("settings").isJsonObject()) item.getValue().settings = value.getAsJsonObject("settings").deepCopy();
            }
        }
    }

    public static synchronized void save() {
        load();
        JsonObject root = new JsonObject();
        root.addProperty("format", 1);
        root.addProperty("note", "Module catalog and toggles only; a toggle does not mean the original feature has been ported.");
        JsonObject modules = new JsonObject();
        for (Entry entry : ENTRIES.values()) {
            JsonObject value = new JsonObject();
            value.addProperty("enabled", entry.enabled);
            value.add("settings", entry.settings.deepCopy());
            modules.add(entry.id, value);
        }
        root.add("modules", modules);
        try {
            Files.createDirectories(CONFIG.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG, StandardCharsets.UTF_8)) { GSON.toJson(root, writer); }
        } catch (IOException e) {
            System.err.println("[Anubis Mobile] Could not save config: " + e.getMessage());
        }
    }

    public static List<Entry> all() { load(); return ENTRIES.values().stream().sorted(Comparator.comparing(e -> e.id)).toList(); }
    public static List<Entry> inCategory(String category) {
        load();
        return ENTRIES.values().stream().filter(e -> e.category.equals(category)).sorted(Comparator.comparing(e -> e.id)).toList();
    }
    public static List<String> categories() {
        load();
        return ENTRIES.values().stream().map(e -> e.category).distinct().sorted().toList();
    }
    public static int enabledCount() { load(); return (int) ENTRIES.values().stream().filter(e -> e.enabled).count(); }
    public static String pretty(String id) {
        String[] parts = id.split("-"); StringBuilder out = new StringBuilder();
        for (String p : parts) { if (!out.isEmpty()) out.append(' '); if (!p.isEmpty()) out.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)); }
        return out.toString();
    }

    private static String categoryFor(String id) {
        if (List.of("aim-assist", "triggerbot", "kill-aura", "mace", "w-tap-recode", "auto-clicker", "hand-aura", "trident-boost").contains(id)) return "Combat";
        if (List.of("freecam", "boat-fly", "speed", "trident-util", "air-stuck", "freelook", "zoom", "render-distance-toggle", "slow-swing").contains(id)) return "Movement";
        if (List.of("esp", "glow-esp", "nametags", "spawner-nametags", "block-esp", "block-overlay", "storage-esp", "pearl-trajectory", "trajectories", "xray", "target-esp", "tracers", "radar", "block-entity-debug", "chunk-scanner", "sus-chunk-finder", "netherite-finder", "amethyst-bypass").contains(id)) return "Render & Finder";
        if (List.of("fullbright", "custom-fov", "custom-crosshair", "custom-glint", "hit-particles", "totem-spirit", "particles", "motion-blur", "atmosphere", "color-grading", "jump-circles", "character-3d", "floating-relics", "time-changer", "swing-animation", "weapon-inspect", "hand-pose").contains(id)) return "Visuals";
        if (List.of("spotify-hud", "region-map", "hotkeys", "name-protect", "no-inv-leak", "weather-notifier", "friend-guard", "auto-relog", "quantum", "player-bypass", "hand-aura").contains(id)) return "Utility";
        return "Misc";
    }

    public static final class Entry {
        public final String id;
        public final String category;
        public boolean enabled;
        public JsonObject settings;
        Entry(String id, String category, boolean enabled, JsonObject settings) {
            this.id = id; this.category = category; this.enabled = enabled; this.settings = settings;
        }
    }
}
