package dev.gian.mobileclient.gui;

import dev.gian.mobileclient.ModuleStore;
import dev.gian.mobileclient.ModuleStore.Entry;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Click GUI with one draggable, collapsible panel per category, a search box and a bottom tab bar.
 * Works with mouse and with touch (a tap is a left click; dragging a header moves the panel).
 * Panel positions are kept for the whole game session.
 */
public final class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 112;
    private static final int HEADER_H = 18;
    private static final int ROW_H = 16;
    private static final int GAP = 6;
    private static final int TOP = 34;
    private static final int BOTTOM_BAR = 30;

    private static final int COL_PANEL = 0xE6101218;
    private static final int COL_HEADER = 0xFF1C2030;
    private static final int COL_ON = 0xFF2F6BFF;
    private static final int COL_HOVER = 0x33FFFFFF;
    private static final int COL_TEXT = 0xFFE6EAF2;
    private static final int COL_DIM = 0xFF8E97AA;

    /** Persistent per-category state (position, collapsed, scroll). */
    private static final Map<String, PanelState> STATES = new HashMap<>();
    private static String rawQuery = "";
    private static int tab = 0; // 0 = Modules, 1 = Config

    private final List<Panel> panels = new ArrayList<>();
    private String query = "";
    private Panel dragging;
    private double dragOffX, dragOffY, dragStartX, dragStartY;
    private boolean dragMoved;

    public ClickGuiScreen() { super(Component.literal("Anubis Mobile")); }

    private static final class PanelState {
        int x, y, scroll;
        boolean collapsed = true;
        PanelState(int x, int y) { this.x = x; this.y = y; }
    }

    private static final class Panel {
        final String category;
        final PanelState st;
        Panel(String category, PanelState st) { this.category = category; this.st = st; }
    }

    @Override protected void init() {
        panels.clear();
        query = rawQuery.toLowerCase(Locale.ROOT);

        int x = GAP, y = TOP;
        for (String category : ModuleStore.categories()) {
            PanelState st = STATES.get(category);
            if (st == null) {
                st = new PanelState(x, y);
                STATES.put(category, st);
                x += PANEL_W + GAP;
                if (x + PANEL_W > width - GAP) { x = GAP; y += HEADER_H + GAP; }
            }
            clamp(st);
            panels.add(new Panel(category, st));
        }

        EditBox search = new EditBox(font, width / 2 - 80, 8, 160, 18, Component.literal("Search"));
        search.setHint(Component.literal("Search modules..."));
        search.setValue(rawQuery);
        search.setResponder(s -> { rawQuery = s; query = s.toLowerCase(Locale.ROOT); });
        addRenderableWidget(search);

        int barY = height - 24;
        addRenderableWidget(Button.builder(Component.literal("Modules"), b -> { tab = 0; rebuildWidgets(); })
                .bounds(width / 2 - 74, barY, 70, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Config"), b -> { tab = 1; rebuildWidgets(); })
                .bounds(width / 2 + 4, barY, 70, 18).build());

        if (tab == 1) {
            addRenderableWidget(Button.builder(Component.literal("Desactivar todo"), b -> {
                for (Entry e : ModuleStore.all()) e.enabled = false;
                ModuleStore.save();
            }).bounds(width / 2 - 70, 80, 140, 22).build());
            addRenderableWidget(Button.builder(Component.literal("Guardar ahora"), b -> ModuleStore.save())
                    .bounds(width / 2 - 70, 108, 140, 22).build());
        }
    }

    private void clamp(PanelState st) {
        st.x = Math.max(0, Math.min(st.x, Math.max(0, width - PANEL_W)));
        st.y = Math.max(0, Math.min(st.y, Math.max(0, height - HEADER_H - BOTTOM_BAR)));
    }

    private List<Entry> entriesOf(Panel p) {
        List<Entry> all = ModuleStore.inCategory(p.category);
        if (query.isEmpty()) return all;
        List<Entry> out = new ArrayList<>();
        for (Entry e : all) {
            if (e.id.contains(query) || ModuleStore.pretty(e.id).toLowerCase(Locale.ROOT).contains(query)) out.add(e);
        }
        return out;
    }

    private boolean visible(Panel p) { return query.isEmpty() || !entriesOf(p).isEmpty(); }
    private boolean open(Panel p) { return !query.isEmpty() || !p.st.collapsed; }

    private int contentHeight(Panel p) { return entriesOf(p).size() * ROW_H; }

    private int bodyHeight(Panel p) {
        if (!open(p)) return 0;
        int max = Math.max(ROW_H, height - BOTTOM_BAR - (p.st.y + HEADER_H));
        return Math.min(contentHeight(p), max);
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        // The game draws the screen background before render(); do not call renderBackground() here.
        if (tab == 0) {
            for (Panel p : panels) {
                if (!visible(p)) continue;
                renderPanel(g, p, mouseX, mouseY);
            }
        } else {
            g.drawCenteredString(font, "ANUBIS MOBILE", width / 2, 40, 0xFFFFFFFF);
            g.drawCenteredString(font, "Modulos activados: " + ModuleStore.enabledCount() + " / " + ModuleStore.all().size(), width / 2, 56, COL_TEXT);
            g.drawCenteredString(font, "Los interruptores guardan configuracion; aun no ejecutan logica.", width / 2, 68, COL_DIM);
        }
        super.render(g, mouseX, mouseY, delta);
    }

    private void renderPanel(GuiGraphics g, Panel p, int mouseX, int mouseY) {
        PanelState st = p.st;
        g.fill(st.x, st.y, st.x + PANEL_W, st.y + HEADER_H, COL_HEADER);
        g.drawString(font, p.category, st.x + 6, st.y + 5, COL_TEXT, false);
        g.drawString(font, open(p) ? "-" : "+", st.x + PANEL_W - 12, st.y + 5, COL_DIM, false);
        if (!open(p)) return;

        List<Entry> entries = entriesOf(p);
        int bodyTop = st.y + HEADER_H;
        int bodyH = bodyHeight(p);
        st.scroll = Math.max(0, Math.min(st.scroll, Math.max(0, contentHeight(p) - bodyH)));
        g.fill(st.x, bodyTop, st.x + PANEL_W, bodyTop + bodyH, COL_PANEL);

        g.enableScissor(st.x, bodyTop, st.x + PANEL_W, bodyTop + bodyH);
        for (int i = 0; i < entries.size(); i++) {
            int ry = bodyTop + i * ROW_H - st.scroll;
            if (ry + ROW_H < bodyTop || ry > bodyTop + bodyH) continue;
            Entry e = entries.get(i);
            if (e.enabled) g.fill(st.x, ry, st.x + PANEL_W, ry + ROW_H, COL_ON);
            if (in(mouseX, mouseY, st.x, ry, PANEL_W, ROW_H) && in(mouseX, mouseY, st.x, bodyTop, PANEL_W, bodyH)) {
                g.fill(st.x, ry, st.x + PANEL_W, ry + ROW_H, COL_HOVER);
            }
            String name = font.plainSubstrByWidth(ModuleStore.pretty(e.id), PANEL_W - 12);
            g.drawString(font, name, st.x + 6, ry + 4, e.enabled ? 0xFFFFFFFF : COL_TEXT, false);
        }
        g.disableScissor();
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) return true;
        if (tab != 0) return false;
        double mx = event.x(), my = event.y();
        int button = event.button();

        for (int i = panels.size() - 1; i >= 0; i--) {
            Panel p = panels.get(i);
            if (!visible(p)) continue;
            PanelState st = p.st;

            if (in(mx, my, st.x, st.y, PANEL_W, HEADER_H)) {
                panels.remove(i);
                panels.add(p); // bring to front
                if (button == 0) {
                    dragging = p;
                    dragOffX = mx - st.x;
                    dragOffY = my - st.y;
                    dragStartX = mx;
                    dragStartY = my;
                    dragMoved = false;
                } else if (button == 1 && query.isEmpty()) {
                    st.collapsed = !st.collapsed;
                }
                return true;
            }

            int bodyTop = st.y + HEADER_H;
            int bodyH = bodyHeight(p);
            if (open(p) && in(mx, my, st.x, bodyTop, PANEL_W, bodyH)) {
                int index = (int) ((my - bodyTop + st.scroll) / ROW_H);
                List<Entry> entries = entriesOf(p);
                if (button == 0 && index >= 0 && index < entries.size()) {
                    Entry e = entries.get(index);
                    e.enabled = !e.enabled;
                    ModuleStore.save();
                }
                return true;
            }
        }
        return false;
    }

    @Override public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != null) {
            double mx = event.x(), my = event.y();
            if (Math.abs(mx - dragStartX) > 3 || Math.abs(my - dragStartY) > 3) dragMoved = true;
            if (dragMoved) {
                dragging.st.x = (int) (mx - dragOffX);
                dragging.st.y = (int) (my - dragOffY);
                clamp(dragging.st);
            }
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override public boolean mouseReleased(MouseButtonEvent event) {
        if (dragging != null) {
            // A tap/click on the header without moving toggles the panel.
            if (!dragMoved && event.button() == 0 && query.isEmpty()) dragging.st.collapsed = !dragging.st.collapsed;
            dragging = null;
            return true;
        }
        return super.mouseReleased(event);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (tab == 0) {
            for (int i = panels.size() - 1; i >= 0; i--) {
                Panel p = panels.get(i);
                if (!visible(p) || !open(p)) continue;
                PanelState st = p.st;
                int bodyTop = st.y + HEADER_H;
                int bodyH = bodyHeight(p);
                if (in(mouseX, mouseY, st.x, bodyTop, PANEL_W, bodyH)) {
                    int max = Math.max(0, contentHeight(p) - bodyH);
                    st.scroll = Math.max(0, Math.min(max, st.scroll - (int) (scrollY * ROW_H * 2)));
                    return true;
                }
            }
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    @Override public void onClose() { ModuleStore.save(); super.onClose(); }
    @Override public boolean isPauseScreen() { return false; }
}
