package dev.gian.mobileclient.gui;

import dev.gian.mobileclient.ModuleStore;
import dev.gian.mobileclient.ModuleStore.Entry;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** Touch-friendly, paginated catalog screen. It has no native/ImGui dependency. */
public final class MobileClickScreen extends Screen {
    private static final int PANEL_HEIGHT = 330;
    private static final int ROW_HEIGHT = 26;
    private static final int BUTTON_HEIGHT = 24;

    private String category = "All";
    private int page = 0;
    private int panelLeft, panelTop, panelWidth, panelBottom;

    public MobileClickScreen() { super(Component.literal("Anubis Mobile")); }

    @Override protected void init() {
        panelWidth = Math.min(360, this.width - 16);
        panelLeft = (this.width - panelWidth) / 2;
        panelTop = Math.max(8, (this.height - PANEL_HEIGHT) / 2);
        panelBottom = Math.min(this.height - 8, panelTop + PANEL_HEIGHT);
        int innerX = panelLeft + 10;
        int innerW = panelWidth - 20;
        int controlY = panelTop + 54;
        addRenderableWidget(Button.builder(Component.literal("‹ Categoría"), b -> cycleCategory(-1))
                .bounds(innerX, controlY, (innerW - 6) / 2, 30).build());
        addRenderableWidget(Button.builder(Component.literal("Categoría ›"), b -> cycleCategory(1))
                .bounds(innerX + (innerW + 6) / 2, controlY, (innerW - 6) / 2, 30).build());

        // The number of rows adapts to the real screen height (phones have very small GUI heights).
        int listTop = panelTop + 92;
        int footerY = panelBottom - 38;
        int rowsPerPage = Math.max(1, (footerY - listTop - 4) / ROW_HEIGHT);

        List<Entry> entries = currentEntries();
        int maxPage = Math.max(0, (entries.size() - 1) / rowsPerPage);
        page = Math.max(0, Math.min(page, maxPage));
        int start = page * rowsPerPage;
        int y = listTop;
        for (int i = start; i < Math.min(entries.size(), start + rowsPerPage); i++) {
            Entry entry = entries.get(i);
            addRenderableWidget(Button.builder(label(entry), b -> {
                entry.enabled = !entry.enabled;
                ModuleStore.save();
                b.setMessage(label(entry));
            }).bounds(innerX, y, innerW, BUTTON_HEIGHT).build());
            y += ROW_HEIGHT;
        }

        addRenderableWidget(Button.builder(Component.literal("◀"), b -> { page = Math.max(0, page - 1); rebuildWidgets(); })
                .bounds(innerX, footerY, 42, 28).build());
        addRenderableWidget(Button.builder(Component.literal((page + 1) + " / " + (maxPage + 1)), b -> { })
                .bounds(innerX + 46, footerY, innerW - 92, 28).build());
        addRenderableWidget(Button.builder(Component.literal("▶"), b -> { page = Math.min(maxPage, page + 1); rebuildWidgets(); })
                .bounds(innerX + innerW - 42, footerY, 42, 28).build());
    }

    private static Component label(Entry entry) {
        return Component.literal((entry.enabled ? "●  ON   " : "○  OFF  ") + ModuleStore.pretty(entry.id));
    }

    private void cycleCategory(int direction) {
        List<String> options = new ArrayList<>();
        options.add("All");
        options.addAll(ModuleStore.categories());
        int idx = options.indexOf(category);
        if (idx < 0) idx = 0;
        idx = (idx + direction + options.size()) % options.size();
        category = options.get(idx);
        page = 0;
        rebuildWidgets();
    }

    private List<Entry> currentEntries() { return category.equals("All") ? ModuleStore.all() : ModuleStore.inCategory(category); }

    @Override public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        // renderBackground() is intentionally not called here: since 1.21.6 the game draws the screen
        // background itself before render(), and a second call can crash with "Can only blur once per frame".
        // Custom screens only need super.render() for widgets (see the Fabric docs custom-screen example).
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelBottom, 0xF0141924);
        graphics.fill(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 38, 0xFF28364A);
        graphics.drawCenteredString(font, "ANUBIS MOBILE", width / 2, panelTop + 8, 0xFFFFFFFF);
        graphics.drawCenteredString(font, category + "  —  " + currentEntries().size() + " módulos", width / 2, panelTop + 27, 0xFFD1D9E6);
        graphics.drawCenteredString(font, "Activados: " + ModuleStore.enabledCount() + "  |  Toca para alternar", width / 2, panelTop + 44, 0xFFB5C5D8);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override public void onClose() { ModuleStore.save(); super.onClose(); }
    @Override public boolean isPauseScreen() { return false; }
}
